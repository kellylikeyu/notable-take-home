This function is used to transcribe doctor's dictations to listed notes.
The function script is written in Javascript.

Using command line on terminal:
a. Write or copy doctor's dictations in the input.txt file.
b. Run
node transcribe.js
c. Transcribed listed notes display on terminal.
